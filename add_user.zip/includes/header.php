<head>
  <meta charset="utf-8" />
  <title></title>
  <link rel="stylesheet" href="assets/bootstrap.min.css" />
  <link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet" />
  <link rel="stylesheet" href="assets/dataTables.bootstrap4.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
</head>